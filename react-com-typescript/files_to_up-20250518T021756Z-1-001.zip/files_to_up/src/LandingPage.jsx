import { useNavigate } from "react-router-dom";
import "./App.css";


export default function LandingPage() {
  const navigate = useNavigate();

  return (
    <div className="font-sans">
      {/* Navigation */}
      <nav>
        <div className="nav-container">
          <div className="nav-inner">
            <div className="nav-logo">
              <i className="fas fa-hard-hat"></i>
              <span className="nav-title">SobraCerta</span>
            </div>
            <div className="nav-links">
              
            </div>
            <div>
              <button 
                onClick={() => navigate("/info")}
              className="start-button pulse-animation hover-scale"
              >
                Comece Agora
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="gradient-bg">
        <div className="hero-container">
          <h1>
            <span className="block">
              Clique aqui para vender ou comprar&nbsp;
            </span>
            <span className="block">
              itens que sobraram de uma obra da sua região
            </span>
          </h1>
          <div className="mt-10">
            <button
              className="hero-button hover-scale"
              onClick={() => navigate("/info")}
            >
              <i className="fas fa-bolt" style={{ marginRight: "0.5rem" }}></i>
              Acessar Plataforma Inteligente
            </button>
            <p className="hero-subtext">
              
            </p>
          </div>
        </div>
      </div>

      {/* Outras seções aqui */}
    </div>
  );
}
