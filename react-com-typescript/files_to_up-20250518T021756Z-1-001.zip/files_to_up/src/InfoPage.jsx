import "./App.css";

export default function InfoPage() {
  return (
    <div className="info-page">
      <h1 className="text-3xl font-bold text-green-700">Plataforma Inteligente</h1>
      <p className="mt-4">Conteúdo da sua página info aqui.</p>
    </div>
  );
}
